﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HiddenWatermark
{
    /// <summary>
    /// Static class for color space conversion methods
    /// </summary>
    internal static class ColorSpaceConversion
    {
        /// <summary>
        /// Convert RGB values to Y component
        /// </summary>
        public static double RgbToY(double red, double green, double blue)
        {
            return 0.299 * red + 0.587 * green + 0.114 * blue;
        }

        /// <summary>
        /// Convert RGB values to U component
        /// </summary>
        public static double RgbToU(double red, double green, double blue)
        {
            return -0.147 * red - 0.289 * green + 0.436 * blue;
        }

        /// <summary>
        /// Convert RGB values to V component
        /// </summary>
        public static double RgbToV(double red, double green, double blue)
        {
            return 0.615 * red - 0.515 * green - 0.100 * blue;
        }

        /// <summary>
        /// Convert YUV values to Red component
        /// </summary>
        public static double YuvToR(double y, double u, double v)
        {
            return y + 1.140 * v;
        }

        /// <summary>
        /// Convert YUV values to Green component
        /// </summary>
        public static double YuvToG(double y, double u, double v)
        {
            return y - 0.395 * u - 0.581 * v;
        }

        /// <summary>
        /// Convert YUV values to Blue component
        /// </summary>
        public static double YuvToB(double y, double u, double v)
        {
            return y + 2.032 * u;
        }
    }
}